Dancing game logic:

\
Enter the dance society\
-> talk to the president\
-> asked to dance, start dancing\
-> one arrow shows on the screen at a time\
-> show the next arrow if the player holds the correct directional key\
-> player gets the id after the whole dance\
-> otherwise sent to the corridor and starts again\

TODO:
Using the loop script:\
- Duplicate the loop \
- Change: actor(arrow) position, direction, the key the player should hold\
\
Add a sound track\
\

Puzzle?